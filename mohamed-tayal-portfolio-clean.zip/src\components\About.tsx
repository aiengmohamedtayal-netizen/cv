import { motion } from "framer-motion";
import { Brain, Code2, Database, GraduationCap } from "lucide-react";

const pillars = [
  { icon: Brain, title: "AI Engineering", text: "LLM agents, RAG systems, fine-tuning, evaluation pipelines." },
  { icon: Database, title: "ML Systems", text: "Data pipelines, vector stores, model serving, observability." },
  { icon: Code2, title: "Full-stack", text: "TypeScript, React, Next.js, Python, FastAPI — end to end." },
  { icon: GraduationCap, title: "Always Learning", text: "Delta University CS · papers, experiments, open source." },
];

export const About = () => (
  <section id="about" className="relative py-28">
    <div className="container grid lg:grid-cols-[1fr_1.2fr] gap-14 items-start">
      <div>
        <div className="section-eyebrow">About</div>
        <h2 className="mt-5 font-display text-4xl md:text-5xl font-bold leading-tight">
          An engineer who treats <span className="text-gradient">AI like product</span>.
        </h2>
        <p className="mt-6 text-muted-foreground leading-relaxed">
          I obsess over the gap between a clever notebook and a system real users depend on. I build
          AI features that are observable, evaluable, and fast — then iterate them in production with
          telemetry, evals, and tight feedback loops.
        </p>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Currently focused on agentic workflows, retrieval-augmented reasoning, and shipping AI into
          delightful full-stack interfaces.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {pillars.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, duration: 0.6 }}
            className="glass rounded-2xl p-6 hover:border-primary/30 transition-colors group"
          >
            <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-primary/20 to-violet/20 border border-primary/20 group-hover:scale-110 transition">
              <p.icon size={18} className="text-primary-glow" />
            </div>
            <div className="mt-4 font-display font-semibold text-lg">{p.title}</div>
            <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{p.text}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);
