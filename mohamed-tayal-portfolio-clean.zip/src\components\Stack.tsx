import { motion } from "framer-motion";

const groups = [
  { title: "AI / ML", items: ["PyTorch", "TensorFlow", "HuggingFace", "LangChain", "LlamaIndex", "OpenAI", "Anthropic", "scikit-learn"] },
  { title: "Backend", items: ["Python", "FastAPI", "Node.js", "PostgreSQL", "pgvector", "Redis", "Docker", "GraphQL"] },
  { title: "Frontend", items: ["TypeScript", "React", "Next.js", "Tailwind", "Framer Motion", "Vite", "Zustand"] },
  { title: "DevOps", items: ["AWS", "Vercel", "Supabase", "GitHub Actions", "Cloudflare", "Linux"] },
];

export const Stack = () => (
  <section id="stack" className="relative py-28">
    <div className="container">
      <div className="text-center max-w-2xl mx-auto">
        <div className="section-eyebrow">Toolkit</div>
        <h2 className="mt-4 font-display text-4xl md:text-5xl font-bold">The <span className="text-gradient">stack</span> I build with.</h2>
      </div>
      <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {groups.map((g, i) => (
          <motion.div
            key={g.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, duration: 0.6 }}
            className="glass rounded-2xl p-6"
          >
            <div className="font-display font-semibold mb-4 flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_10px_hsl(var(--primary))]" />
              {g.title}
            </div>
            <div className="flex flex-wrap gap-2">
              {g.items.map((t) => <span key={t} className="chip">{t}</span>)}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);
