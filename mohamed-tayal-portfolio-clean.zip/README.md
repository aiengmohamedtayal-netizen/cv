# Mohamed Tayal — AI Engineer Portfolio

A premium, animated personal portfolio for an AI engineer. Built with React, Vite, TypeScript, Tailwind CSS, shadcn/ui and Framer Motion.

## ✨ Features

- Cinematic hero with animated AI terminal, parallax orbs and magnetic CTAs
- Mouse-reactive cursor glow
- Spotlight project cards with animated technology chips
- Realistic stats with scroll-triggered count-up animation
- About, Stack, Experience timeline (incl. Delta University)
- Futuristic contact section with WhatsApp quick-connect and social links
- Glassmorphism, ambient grid overlay and subtle noise texture
- Fully responsive, dark by default, semantic design tokens

## 🧰 Tech Stack

- **Framework:** React 18 + Vite 5
- **Language:** TypeScript 5
- **Styling:** Tailwind CSS 3 + custom HSL design tokens
- **UI primitives:** shadcn/ui (Radix UI)
- **Animation:** Framer Motion
- **Icons:** lucide-react
- **Routing:** react-router-dom
- **State / data:** @tanstack/react-query

## 🚀 Getting Started

### Prerequisites
- Node.js **18+** (or Bun 1.x)
- npm, pnpm, bun, or yarn

### Install

```bash
npm install
```

### Run the dev server

```bash
npm run dev
```

The app will be served at http://localhost:8080 (configured in `vite.config.ts`).

### Build for production

```bash
npm run build
```

The static output is emitted to `dist/`.

### Preview the production build

```bash
npm run preview
```

### Lint

```bash
npm run lint
```

## 📂 Project Structure

```
.
├── public/                 # Static assets served as-is
├── src/
│   ├── components/         # Page sections (Hero, Projects, Stats, ...)
│   │   └── ui/             # shadcn/ui primitives
│   ├── hooks/              # Reusable React hooks
│   ├── lib/                # Utilities (cn helper, etc.)
│   ├── pages/              # Route-level components (Index, NotFound)
│   ├── App.tsx             # Router + providers
│   ├── main.tsx            # App entry
│   └── index.css           # Tailwind layers + design tokens
├── index.html
├── tailwind.config.ts
├── vite.config.ts
├── tsconfig*.json
└── package.json
```

## 🎨 Design System

All colors, gradients, fonts and shadows are defined as HSL CSS variables in `src/index.css` and exposed to Tailwind via `tailwind.config.ts`. Components consume only semantic tokens (`primary`, `violet`, `muted`, `card`, etc.) — never hard-coded colors.

To rebrand, edit the variables under `:root` in `src/index.css`.

## 🔐 Environment Variables

This project does not require any environment variables out of the box. If you add integrations (analytics, contact form backend, etc.) copy `.env.example` to `.env.local` and fill in your keys:

```bash
cp .env.example .env.local
```

Vite only exposes variables prefixed with `VITE_` to the client.

## ☁️ Deployment

The project builds to a fully static `dist/` folder and deploys to any static host:

- **Vercel** — Import the repo, framework preset: *Vite*. Build: `npm run build`, output: `dist`.
- **Netlify** — Build command: `npm run build`, publish directory: `dist`.
- **Cloudflare Pages** — Build: `npm run build`, output: `dist`.
- **GitHub Pages / S3 / any static host** — Upload the contents of `dist/`.

## 📝 License

Personal portfolio — all rights reserved © Mohamed Tayal.
